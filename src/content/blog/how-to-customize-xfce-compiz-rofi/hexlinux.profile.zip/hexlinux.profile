[showmouse]
s0_color = #ffdf3fff

[firepaint]
s0_fire_color = #ff3305ff

[ezoom]
s0_zoom_box_outline_color = #2f2f4f9f
s0_zoom_box_fill_color = #2f2f2f4f

[composite]
s0_unredirect_match = (any) & !(class=Totem) & !(class=MPlayer) & !(class=Vlc) & !(class=Plugin-container) & !(class=Firefox)

[decor]
s0_active_shadow_color = #00000080
s0_active_shadow_x_offset = 0
s0_active_shadow_y_offset = 0
s0_inactive_shadow_x_offset = 0
s0_inactive_shadow_y_offset = 0
s0_command = gtk-window-decorator --metasity-theme Arc-Flatabulous-Dark --replace
s0_decoration_match = !state=maxvert

[gnomecompat]
s0_run_command_screenshot_key = Disabled
s0_command_window_screenshot = xfce4-screenshooter
s0_run_command_window_screenshot_key = Print
s0_command_terminal = xfce4-terminal
s0_run_command_terminal_key = <Control><Alt>t

[freewins]
s0_circle_color = #54befb80
s0_line_color = #1800ffff
s0_cross_line_color = #1800ffff

[switcher]
s0_next_key = Disabled
s0_zoom = 0.800000
s0_auto_rotate = true
s0_background_color = #333333d9

[core]
s0_active_plugins = core;composite;opengl;copytex;decor;compiztoolbox;text;regex;workspacenames;vpswitch;mousepoll;grid;animation;wall;resize;commands;winrules;move;wobbly;place;shift;gnomecompat;imgpng;session;expo;fade;ezoom;workarounds;notification;obs;scale;switcher;
s0_outputs = 1366x768+0+0;
s0_focus_prevention_match = (any)
s0_close_window_key = <Control>q
s0_hsize = 2
s0_vsize = 2

[shift]
s0_initiate_key = <Alt>Tab
s0_initiate_edge = BottomLeft
s0_ground_color1 = #09020292
s0_ground_color2 = #b3b3b300
s0_mode = 1

[animation]
s0_open_effects = animation:Zoom;animation:Dream;animation:Fade;
s0_open_durations = 300;100;80;
s0_close_effects = animation:Zoom;animation:Dream;animation:Dream;
s0_close_durations = 300;80;50;
s0_close_matches = (type=Normal | Dialog | ModalDialog | Unknown) & !(name=gnome-screensaver);(type=Menu | PopupMenu | DropdownMenu | Combo);(type=Tooltip | Notification | Utility) & !(name=compiz) & !(title=notify-osd) & !(name=xfce4-notifyd);
s0_minimize_effects = animation:Magic Lamp Wavy;
s0_minimize_durations = 500;
s0_unminimize_durations = 500;
s0_shade_random_effects = animation:Roll Up;
s0_focus_effects = animation:Wave;
s0_focus_durations = 522;

[screenshot]
s0_selection_outline_color = #2f2f4f9f
s0_selection_fill_color = #2f2f4f4f

[cubeaddon]
s0_ground_color1 = #b3b3b3cc
s0_ground_color2 = #b3b3b300
s0_top_images = /home/alireza/Pictures/xfce4logo.png;
s0_bottom_images = /home/alireza/Pictures/Ustanovka_xubuntu-logo.png;

[staticswitcher]
s0_background_color = #333333d9

[thumbnail]
s0_thumb_color = #0000007f
s0_font_background_color = #0000007f

[resizeinfo]
s0_gradient_1 = #cccce6cc
s0_gradient_2 = #f3f3f3cc
s0_gradient_3 = #d9d9d9cc
s0_outline_color = #e6e6e6ff

[cube]
s0_skydome = true

[winrules]
s0_skiptaskbar_match = (class=Covergloobus.py) & class=conky
s0_skippager_match = (class=Covergloobus.py) & class=conky
s0_below_match = (class=Covergloobus.py) & class=conky
s0_sticky_match = (class=Covergloobus.py) & class=conky
s0_no_move_match = class=conky
s0_no_resize_match = (class=Covergloobus.py) & class=conky
s0_no_minimize_match = (class=Covergloobus.py) & class=conky
s0_no_maximize_match = (class=Covergloobus.py) & class=conky
s0_no_close_match = (class=Covergloobus.py) & class=conky
s0_no_focus_match = (class=Covergloobus.py) & class=conky

[move]
s0_opacity = 58

[obs]
s0_opacity_matches = Tooltip | Menu | PopupMenu | DropdownMenu;
s0_opacity_values = 74;0;

[wall]
s0_miniscreen = true
s0_outline_color = #333333d9
s0_background_gradient_base_color = #cccce6d9
s0_background_gradient_highlight_color = #f3f3ffd9
s0_background_gradient_shadow_color = #f3f3ffd9
s0_thumb_gradient_base_color = #33333359
s0_thumb_gradient_highlight_color = #3f3f3f3f
s0_thumb_highlight_gradient_base_color = #fffffff3
s0_thumb_highlight_gradient_shadow_color = #dfdfdfa6
s0_arrow_base_color = #e6e6e6d9
s0_arrow_shadow_color = #dcdcdcd9
s0_allow_wraparound = true

[expo]
s0_expo_key = <Control><Alt>Arabic_seen
s0_expo_edge = BottomRight
s0_deform = 2
s0_ground_color1 = #b3b3b3cc
s0_ground_color2 = #b3b3b300

